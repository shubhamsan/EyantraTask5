ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
    ur5.hard_set_joint_angles(lst_joint_angles_1, 5)
    request = vacuumGripperRequest(True)
    client(request)
    ur5.hard_set_joint_angles(lst_joint_angles_1_back, 5)
    ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
    ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
    request = vacuumGripperRequest(False)
    client(request)


    ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
    ur5.hard_set_joint_angles(lst_joint_angles_4, 5)
    request = vacuumGripperRequest(True)
    client(request)
    ur5.hard_set_joint_angles(lst_joint_angles_4_back, 5)
    ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
    ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
    request = vacuumGripperRequest(False)
    client(request)

    ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
    ur5.hard_set_joint_angles(lst_joint_angles_7, 5)
    request = vacuumGripperRequest(True)
    client(request)
    ur5.hard_set_joint_angles(lst_joint_angles_7_back, 5)
    ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
    ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
    request = vacuumGripperRequest(False)
    client(request)

    ur5.hard_set_joint_angles(lst_joint_angles_10, 5)
    request = vacuumGripperRequest(True)
    client(request)
    ur5.ee_cartesian_translation(0, 0.5, 0)
    ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
    ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
    request = vacuumGripperRequest(False)
    client(request)

    ur5.hard_set_joint_angles(lst_joint_angles_straight_180, 5)
    ur5.hard_set_joint_angles(lst_joint_angles_3, 5)
    request = vacuumGripperRequest(True)
    client(request)
    ur5.ee_cartesian_translation(0, 0.5, 0)
    ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
    request = vacuumGripperRequest(False)
    client(request)

    ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
    ur5.hard_set_joint_angles(lst_joint_angles_6_1, 5)
    request = vacuumGripperRequest(True)
    client(request)
    ur5.hard_set_joint_angles(lst_joint_angles_6_back, 5)
    ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
    ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
    request = vacuumGripperRequest(False)
    client(request)

    ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
    ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'straight_to_pose9.yaml', 5)
    request = vacuumGripperRequest(True)
    client(request)
    ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'pose9_to_pose9back.yaml', 5)
    ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'pose9back_to_straight.yaml', 5)
    ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
    request = vacuumGripperRequest(False)
    client(request)

    ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
    ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'straight_to_pose12.yaml', 5)
    request = vacuumGripperRequest(True)
    client(request)
    ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'pose12_to_pose12back.yaml', 5)
    ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'pose12back_to_straight.yaml', 5)
    ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
    request = vacuumGripperRequest(False)
    client(request)

    ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
    ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'straight_to_straight180.yaml', 5)
    ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'straight_to_pose5.yaml', 5)
    request = vacuumGripperRequest(True)
    client(request)
    ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'pose5_to_pose5back.yaml', 5)
    ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
    ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
    request = vacuumGripperRequest(False)
    client(request)

    ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
    ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'straight_to_pose8.yaml', 5)
    request = vacuumGripperRequest(True)
    client(request)
    ur5.hard_set_joint_angles(lst_joint_angles_8_back, 5)
    ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'pose8back_to_straight.yaml', 5)
    ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
    request = vacuumGripperRequest(False)
    client(request)

    ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
    ur5.hard_set_joint_angles(lst_joint_angles_11, 5)
    request = vacuumGripperRequest(True)
    client(request)
    ur5.ee_cartesian_translation(0, 0.5, 0)
    ur5.go_to_pose(ur5_2_home_pose)
    ur5.go_to_pose(ur5_2_home_pose)
    ur5.go_to_pose(ur5_2_home_pose)
    request = vacuumGripperRequest(False)
    client(request)
    ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)

while True:
    for i in range(len(ur5.received_msg)):
        print(ur5.color)
        if ((ur5.received_msg[i] == "HP") and (ur5.color[0] == "red")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_1, 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.hard_set_joint_angles(lst_joint_angles_1_back, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[0] = "done"
        if ((ur5.received_msg[i] == "HP") and (ur5.color[3] == "red")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_4, 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.hard_set_joint_angles(lst_joint_angles_4_back, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[3] = "done"
        if ((ur5.received_msg[i] == "HP") and (ur5.color[4] == "red")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'straight_to_pose5.yaml', 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'pose5_to_pose5back.yaml', 5)
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[4] = "done"
        if ((ur5.received_msg[i] == "HP") and (ur5.color[5] == "red")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_6_1, 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.hard_set_joint_angles(lst_joint_angles_6_back, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[5] = "done"
        if ((ur5.received_msg[i] == "HP") and (ur5.color[6] == "red")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_7, 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.hard_set_joint_angles(lst_joint_angles_7_back, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[6] = "done"
        if ((ur5.received_msg[i] == "HP") and (ur5.color[7] == "red")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'straight_to_pose8.yaml', 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.hard_set_joint_angles(lst_joint_angles_8_back, 5)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'pose8back_to_straight.yaml', 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[7] = "done"
        if ((ur5.received_msg[i] == "HP") and (ur5.color[9] == "red")):
            ur5.hard_set_joint_angles(lst_joint_angles_10, 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.ee_cartesian_translation(0, 0.5, 0)
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[9] = "done"
        if ((ur5.received_msg[i] == "HP") and (ur5.color[11] == "red")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'straight_to_pose12.yaml', 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'pose12_to_pose12back.yaml', 5)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'pose12back_to_straight.yaml', 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[11] = "done"
        if ((ur5.received_msg[i] == "MP") and (ur5.color[0] == "yellow")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_1, 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.hard_set_joint_angles(lst_joint_angles_1_back, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[0] = "done"
        if ((ur5.received_msg[i] == "MP") and (ur5.color[3] == "yellow")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_4, 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.hard_set_joint_angles(lst_joint_angles_4_back, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[3] = "done"
        if ((ur5.received_msg[i] == "MP") and (ur5.color[4] == "yellow")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'straight_to_pose5.yaml', 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.hard_set_joint_angles(lst_joint_angles_5_back, 5)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'pose5back_to_straight.yaml', 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[4] = "done"
        if ((ur5.received_msg[i] == "MP") and (ur5.color[5] == "yellow")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_6_1, 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.hard_set_joint_angles(lst_joint_angles_6_back, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[5] = "done"
        if ((ur5.received_msg[i] == "MP") and (ur5.color[6] == "yellow")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_7, 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.hard_set_joint_angles(lst_joint_angles_7_back, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[6] = "done"
        if ((ur5.received_msg[i] == "MP") and (ur5.color[7] == "yellow")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'straight_to_pose8.yaml', 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.hard_set_joint_angles(lst_joint_angles_8_back, 5)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'pose8back_to_straight.yaml', 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[7] = "done"
        if ((ur5.received_msg[i] == "MP") and (ur5.color[9] == "yellow")):
            ur5.hard_set_joint_angles(lst_joint_angles_10, 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.ee_cartesian_translation(0, 0.5, 0)
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[9] = "done"
        if ((ur5.received_msg[i] == "MP") and (ur5.color[11] == "yellow")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'straight_to_pose12.yaml', 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'pose12_to_pose12back.yaml', 5)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'pose12back_to_straight.yaml', 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[11] = "done"
        if ((ur5.received_msg[i] == "LP") and (ur5.color[0] == "green")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_1, 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.hard_set_joint_angles(lst_joint_angles_1_back, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[0] = "done"
        if ((ur5.received_msg[i] == "LP") and (ur5.color[3] == "green")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_4, 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.hard_set_joint_angles(lst_joint_angles_4_back, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[3] = "done"
        if ((ur5.received_msg[i] == "LP") and (ur5.color[4] == "green")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'straight_to_pose5.yaml', 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'pose5_to_pose5back.yaml', 5)
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[4] = "done"
        if ((ur5.received_msg[i] == "LP") and (ur5.color[5] == "green")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_6_1, 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.hard_set_joint_angles(lst_joint_angles_6_back, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[5] = "done"
        if ((ur5.received_msg[i] == "LP") and (ur5.color[6] == "green")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_7, 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.hard_set_joint_angles(lst_joint_angles_7_back, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[6] = "done"
        if ((ur5.received_msg[i] == "LP") and (ur5.color[7] == "green")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'straight_to_pose8.yaml', 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.hard_set_joint_angles(lst_joint_angles_8_back, 5)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'pose8back_to_straight.yaml', 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[7] = "done"
        if ((ur5.received_msg[i] == "LP") and (ur5.color[9] == "green")):
            ur5.hard_set_joint_angles(lst_joint_angles_10, 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.ee_cartesian_translation(0, 0.5, 0)
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[9] = "done"
        if ((ur5.received_msg[i] == "LP") and (ur5.color[11] == "green")):
            ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'straight_to_pose12.yaml', 5)
            request = vacuumGripperRequest(True)
            client(request)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'pose12_to_pose12back.yaml', 5)
            ur5.moveit_hard_play_planned_path_from_file(ur5._file_path, 'pose12back_to_straight.yaml', 5)
            ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
            request = vacuumGripperRequest(False)
            client(request)
            ur5.received_msg[i] = "done"
            ur5.color[11] = "done"



        if li[0] == "done":
            parameters = {"id": "OrdersDispatched", "Team id": "VB_1082", "Unique Id": "shamohsh",
                          "Order ID": self.msg[0]["Order ID"],
                          "Item": self.msg[0]["Item"], "Priority": self.msg[0]["Priority"], "City": self.msg[0]["City"],
                          "Dispatch Quantity": self.msg[0]["Order Quantity"],"Cost": self.msg[0]["Cost"],
                          "Dispatch Status": "Yes", "Dispatch Date and Time": self.get_time_str()}
            URL1 = "https://script.google.com/macros/s/AKfycbzXEoxv76faxmZM3dJFkXPIrsTg0cbDGrD_rMEuWQX1PGYKgDIMKMxV/exec"
            response1 = requests.get(URL1, params=parameters)
            li[0] = "None"
        if li[0] == "done":
            parameters = {"id": "OrdersDispatched", "Team id": "VB_1082", "Unique Id": "shamohsh",
                          "Order ID": self.msg[1]["Order ID"],
                          "Item": self.msg[1]["Item"], "Priority": self.msg[1]["Priority"], "City": self.msg[1]["City"],
                          "Dispatch Quantity": self.msg[1]["Order Quantity"],"Cost": self.msg[1]["Cost"],
                          "Dispatch Status": "Yes", "Dispatch Date and Time": self.get_time_str()}
            URL1 = "https://script.google.com/macros/s/AKfycbzXEoxv76faxmZM3dJFkXPIrsTg0cbDGrD_rMEuWQX1PGYKgDIMKMxV/exec"
            response1 = requests.get(URL1, params=parameters)
            li[1] = "None"
        if li[2] == "done":
            parameters = {"id": "OrdersDispatched", "Team id": "VB_1082", "Unique Id": "shamohsh",
                          "Order ID": self.msg[2]["Order ID"],
                          "Item": self.msg[2]["Item"], "Priority": self.msg[2]["Priority"], "City": self.msg[2]["City"],
                          "Dispatch Quantity": self.msg[2]["Order Quantity"],"Cost": self.msg[2]["Cost"],
                          "Dispatch Status": "Yes", "Dispatch Date and Time": self.get_time_str()}
            URL1 = "https://script.google.com/macros/s/AKfycbzXEoxv76faxmZM3dJFkXPIrsTg0cbDGrD_rMEuWQX1PGYKgDIMKMxV/exec"
            response1 = requests.get(URL1, params=parameters)
            li[2] = "None"
        if li[3] == "done":
            parameters = {"id": "OrdersDispatched", "Team id": "VB_1082", "Unique Id": "shamohsh",
                          "Order ID": self.msg[3]["Order ID"],
                          "Item": self.msg[3]["Item"], "Priority": self.msg[3]["Priority"], "City": self.msg[3]["City"],
                          "Dispatch Quantity": self.msg[3]["Order Quantity"],"Cost": self.msg[3]["Cost"],
                          "Dispatch Status": "Yes", "Dispatch Date and Time": self.get_time_str()}
            URL1 = "https://script.google.com/macros/s/AKfycbzXEoxv76faxmZM3dJFkXPIrsTg0cbDGrD_rMEuWQX1PGYKgDIMKMxV/exec"
            response1 = requests.get(URL1, params=parameters)
            li[3] = "None"
        if li[4] == "done":
            parameters = {"id": "OrdersDispatched", "Team id": "VB_1082", "Unique Id": "shamohsh",
                          "Order ID": self.msg[4]["Order ID"],
                          "Item": self.msg[4]["Item"], "Priority": self.msg[4]["Priority"], "City": self.msg[4]["City"],
                          "Dispatch Quantity": self.msg[4]["Order Quantity"],"Cost": self.msg[4]["Cost"],
                          "Dispatch Status": "Yes", "Dispatch Date and Time": self.get_time_str()}
            URL1 = "https://script.google.com/macros/s/AKfycbzXEoxv76faxmZM3dJFkXPIrsTg0cbDGrD_rMEuWQX1PGYKgDIMKMxV/exec"
            response1 = requests.get(URL1, params=parameters)
            li[4] = "None"
        if li[5] == "done":
            parameters = {"id": "OrdersDispatched", "Team id": "VB_1082", "Unique Id": "shamohsh",
                          "Order ID": self.msg[5]["Order ID"],
                          "Item": self.msg[5]["Item"], "Priority": self.msg[5]["Priority"], "City": self.msg[5]["City"],
                          "Dispatch Quantity": self.msg[5]["Order Quantity"],"Cost": self.msg[5]["Cost"],
                          "Dispatch Status": "Yes", "Dispatch Date and Time": self.get_time_str()}
            URL1 = "https://script.google.com/macros/s/AKfycbzXEoxv76faxmZM3dJFkXPIrsTg0cbDGrD_rMEuWQX1PGYKgDIMKMxV/exec"
            response1 = requests.get(URL1, params=parameters)
            #li[5] = "None"
        if li[6] == "done":
            parameters = {"id": "OrdersDispatched", "Team id": "VB_1082", "Unique Id": "shamohsh",
                          "Order ID": self.msg[6]["Order ID"],
                          "Item": self.msg[6]["Item"], "Priority": self.msg[6]["Priority"], "City": self.msg[6]["City"],
                          "Dispatch Quantity": self.msg[6]["Order Quantity"],"Cost": self.msg[6]["Cost"],
                          "Dispatch Status": "Yes", "Dispatch Date and Time": self.get_time_str()}
            URL1 = "https://script.google.com/macros/s/AKfycbzXEoxv76faxmZM3dJFkXPIrsTg0cbDGrD_rMEuWQX1PGYKgDIMKMxV/exec"
            response1 = requests.get(URL1, params=parameters)
            #li[6] = "None"
        if li[7] == "done":
            parameters = {"id": "OrdersDispatched", "Team id": "VB_1082", "Unique Id": "shamohsh",
                          "Order ID": self.msg[7]["Order ID"],
                          "Item": self.msg[7]["Item"], "Priority": self.msg[7]["Priority"], "City": self.msg[7]["City"],
                          "Dispatch Quantity": self.msg[7]["Order Quantity"],"Cost": self.msg[7]["Cost"],
                          "Dispatch Status": "Yes", "Dispatch Date and Time": self.get_time_str()}
            URL1 = "https://script.google.com/macros/s/AKfycbzXEoxv76faxmZM3dJFkXPIrsTg0cbDGrD_rMEuWQX1PGYKgDIMKMxV/exec"
            response1 = requests.get(URL1, params=parameters)
            #li[7] = "None"
        if li[8] == "done":
            parameters = {"id": "OrdersDispatched", "Team id": "VB_1082", "Unique Id": "shamohsh",
                          "Order ID": self.msg[8]["Order ID"],
                          "Item": self.msg[8]["Item"], "Priority": self.msg[8]["Priority"], "City": self.msg[8]["City"],
                          "Dispatch Quantity": self.msg[8]["Order Quantity"],"Cost": self.msg[8]["Cost"],
                          "Dispatch Status": "Yes", "Dispatch Date and Time": self.get_time_str()}
            URL1 = "https://script.google.com/macros/s/AKfycbzXEoxv76faxmZM3dJFkXPIrsTg0cbDGrD_rMEuWQX1PGYKgDIMKMxV/exec"
            response1 = requests.get(URL1, params=parameters)
            #li[0] = "None"


        """for i in range(len(self.msg)):
            if s == "done":
                parameters = {"id": "OrdersDispatched", "Team id": "VB_1082", "Unique Id": "shamohsh",
                              "Order ID": self.msg[i]["Order ID"],
                              "Item": self.msg[i]["Item"], "Priority": self.msg[i]["Priority"],
                              "City": self.msg[i]["City"],
                              "Dispatch Quantity": self.msg[i]["Order Quantity"], "Cost": self.msg[i]["Cost"],
                              "Dispatch Status": "Yes", "Dispatch Date and Time": self.get_time_str()}
                URL1 = "https://script.google.com/macros/s/AKfycbzXEoxv76faxmZM3dJFkXPIrsTg0cbDGrD_rMEuWQX1PGYKgDIMKMxV/exec"
                response1 = requests.get(URL1, params=parameters)"""
